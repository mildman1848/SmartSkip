# -*- coding: utf-8 -*-
def generate_edl_for_video(video_path):
    # Platzhalter für intro-skipper-Aufruf
    print(f"Generating EDL for {video_path}")
