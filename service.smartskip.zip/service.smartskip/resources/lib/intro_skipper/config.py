# Angepasste Konfiguration für lokale Nutzung
