# Portierter Code aus intro-skipper
